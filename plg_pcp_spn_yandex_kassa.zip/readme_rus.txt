
см. описание на сайте http://seoprosto.net/services/software/joomla-phocacart-yandex-kassa
или загрузите http://seoprosto.net/other/download