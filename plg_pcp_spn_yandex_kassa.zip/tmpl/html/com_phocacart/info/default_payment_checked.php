<?php
/* @package Joomla
 * @copyright Copyright (C) Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * @extension Phoca Extension
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();
// ORDER PROCESSED - DOWNLOADABLE ITEMS - PAYMENT MADE (Payment made, link to download could be possible) (PAYMENT/DOWNLOAD)	
// if user is logged in he/she will get the information about the download link
// if user is a guest - because of security reason we will not display the download link (by security token),
// user should get it per email

$session = JFactory::getSession();
//$session->get('infoaction', 0, 'phocaCart');
$token=$session->get('ykpaymentid', '', 'phocaCart');
$infomessage="Заказ офомлен, но статус платежа не определен!";
if($token != ''){
		$db 		= JFactory::getDBO();
		$query = ' SELECT status_id FROM #__phocacart_orders WHERE order_token = '.$db->quote($token);
		$db->setQuery($query);
		$stateid = $db->loadResult(); 
		if($stateid == 1){
			$infomessage="Заказ оформлен, но платеж еще не подтвержден банком!";
		}
		elseif($stateid >= 2){
			$infomessage="Заказ оформлен и платеж уже подтвержден банком!";
		}
		else {
			$infomessage="Заказ оформлен, но платеж имеет непонятный статус!";
		}
}
echo '<div class="alert alert-success">';
echo $infomessage;
echo '</div>';

if ($this->u->id > 0) {
	echo '<div><a href="'.PhocacartRoute::getDownloadRoute().'">'.'&nbsp;'.JText::_('COM_PHOCACART_DOWNLOAD_LINK').'</a></div>';
}
?>