<?php
/**
 * @version		1.0.4
 * @package		plg_pcp_payment_on_invoice
 * @author		Sergey Kuznetsov http://www.seoprosto.net
 * @copyright	Copyright (c) 2018 SeoProsto.Net. All rights reserved.
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.filesystem.file');
jimport( 'joomla.html.parameter' );
// For mail
jimport('joomla.mail.mail');

//jimport('joomla.log.log');
//JLog::addLogger( array('text_file' => 'com_phocacart_error_log.php'), JLog::ALL, array('com_phocacart'));
//JLoader::register('PhocacartLoader', JPATH_ADMINISTRATOR.'/components/com_phocacart/libraries/loader.php');

JLoader::register('PhocacartOrder', JPATH_ADMINISTRATOR.'/components/com_phocacart/libraries/phocacart/order/order.php');
JLoader::register('PhocaCartLog', JPATH_ADMINISTRATOR.'/components/com_phocacart/libraries/phocacart/log/log.php');

if (! class_exists('PhocacartLoader')) {
   require_once( JPATH_ADMINISTRATOR.'/components/com_phocacart/libraries/loader.php');
} 

//include_once(__DIR__.'/helpers/num2word.php');

phocacartimport('phocacart.utils.log');
//JLoader::registerPrefix('Phocacart', JPATH_ADMINISTRATOR . '/components/com_phocacart/libraries/phocacart');

// Yandex Kassa
//
// Activate the dependency
require __DIR__ . '/lib/autoload.php';
// Activate the dependency
//require __DIR__ . '/vendor/autoload.php';
// Import required classes
use YandexCheckout\Client;
use YandexCheckout\Model\Receipt;
use YandexCheckout\Model\ReceiptItem;
use YandexCheckout\Model\MonetaryAmount;
use YandexCheckout\Model\PaymentMethodType;
use YandexCheckout\Model\ConfirmationType;
use YandexCheckout\Request\Payments\Payment\CreateCaptureRequest;
use YandexCheckout\Request\Payments\CreatePaymentRequest;

class plgPCPSPN_Yandex_Kassa extends JPlugin{
	public $client;

	function __construct(& $subject, $config) {
		parent :: __construct($subject, $config);
		$this->loadLanguage();
	}
	function getPaymentSubject( $par ){
		$payment_Subject=array(
				'1' => 'commodity',
				'2' => 'excise',
				'3' => 'job',
				'4' => 'service',
				'5' => 'gambling_bet',
				'6' => 'gambling_prize',
				'7' => 'lottery',
				'8' => 'lottery_prize',
				'9' => 'intellectual_activity',
				'10' => 'payment',
				'11' => 'agent_commission',
				'12' => 'composite',
				'13' => 'another'
				);
		if(isset($payment_Subject[$par]))
			return $payment_Subject[$par];
		else 
			return $payment_Subject['1'];
	}
	function getPaymentMode( $par ){
		$payment_Mode=Array(
				'1' => 'full_prepayment',
				'2' => 'partial_prepayment',
				'3' => 'advance',
				'4' => 'full_payment',
				'5' => 'partial_payment',
				'6' => 'credit',
				'7' => 'credit_payment'
				);
		if(isset($payment_Mode[$par]))
			return $payment_Mode[$par];
		else
			return $payment_Mode['1'];
	}
	
	function getPaymentMethods(){
		$Payment_methods=array(
			'1' => array(PaymentMethodType::BANK_CARD,'bank_card', JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_METHOD_BANK_CARD')),
			'2' => array(PaymentMethodType::YANDEX_MONEY,'yandex_money',JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_METHOD_YANDEX_MONEY')),
			'3' => array(PaymentMethodType::SBERBANK,'sberbank',JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_METHOD_SBERBANK')),
			'4' => array(PaymentMethodType::QIWI,'qiwi',JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_METHOD_QIWI')),
			'5' => array(PaymentMethodType::WEBMONEY,'webmoney',JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_METHOD_WEBMONEY')),
			'6' => array(PaymentMethodType::CASH,'cash',JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_METHOD_CASH')),
			'7' => array(PaymentMethodType::MOBILE_BALANCE,'mobile_balance',JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_METHOD_MOBILE_BALANCE')),
			'8' => array(PaymentMethodType::ALFABANK,'alfabank',JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_METHOD_ALFABANK'))
		);
		return $Payment_methods;
	}
	function changeStatusInOrder($orderId, $statusId, $notifyUser = 99) {
		// $notifyUser 0 ... no  1 ... yes 99 ... defined in order status settings 
		/*
		$db 		= JFactory::getDBO();
		$query = ' UPDATE #__phocacart_orders SET status_id = '.(int)$statusId
		.' WHERE id = '.(int)$orderId;
		$db->setQuery($query);
		$db->execute();
		PhocacartLog::add(1,JText::_('PLG_PCP_YANDEX_KASSA_CHANGE_STATUS_PAYMENT'), $orderId, $statusId);
		if($statusId == 2){
			$session = JFactory::getSession();
		}
		*/
		PhocacartOrderStatus::changeStatusInOrderTable($orderId, $statusId);
		//PhocacartOrderStatus::changeStatus($orderId, $statusId,'',$notifyUser);
		PhocacartOrderStatus::changeStatus($orderId, $statusId,'',$notifyUser);
		return true;
	}
	function changeStatusInOrderByToken($token, $statusId) {
		$db 		= JFactory::getDBO();
		$query = ' UPDATE #__phocacart_orders SET status_id = '.(int)$statusId
		.' WHERE order_token = '.$db->quote($token);
		$db->setQuery($query);
		$db->execute();
		return true;
	} 
	function getOrderByToken($token) {
		$db 		= JFactory::getDBO();
		$query = ' SELECT id FROM #__phocacart_orders WHERE order_token = '.$db->quote($token);
		$db->setQuery($query);
		$result = $db->loadResult(); 
		return $result;
	} 
	function changeTokenInOrder($orderId, $token) {
		$db 		= JFactory::getDBO();
		$query = ' UPDATE #__phocacart_orders SET order_token = '.$db->quote($token)
		.' WHERE id = '.(int)$orderId;
		$db->setQuery($query);
		$db->execute();
		return true;
	}
	/**
	 * Proceed to payment - some method do not have proceed to payment gateway like e.g. cash on delivery
	 *
	 * @param   integer	$proceed  Proceed or not proceed to payment gateway
	 * @param   string	$message  Custom message array set by plugin to override standard messages made by component
	 *
	 * @return  boolean  True
	 */
	function PCPbeforeProceedToPayment(&$proceed, &$message) {
		
		// THERE ARE 3 PLACES WHERE THE MESSAGE CAN BE CREATED:
		// 1) COMPONENT - components/com_phocacart/views/info/tmpl/ ...
		// 2) LANGUAGE FILE - there is specific string in language file which can be customized for each e-shop (see top of ini file)
		// 3) PAYMENT PLUGIN - means that payment plugin can override the component (1) and language file (2) message
		// See examples:
		
		$proceed = 1;
		$message = array();
		/*
		 // Order processed successfully made - no downloadable items
		 $message['order_nodownload'] 	= JText::_('COM_PHOCACART_ORDER_SUCCESSFULLY_PROCESSED')
		 .'</br>' . JText::_('COM_PHOCACART_ORDER_PROCESSED_ADDITIONAL_INFO');
		 // Order processed successfully made - downloadable items
		 $message['order_download'] 		= JText::_('COM_PHOCACART_ORDER_SUCCESSFULLY_PROCESSED')
		 .'</br>' . JText::_('COM_PHOCACART_ORDER_PROCESSED_DOWNLOADABLE_ITEMS_ADDITIONAL_INFO');
		 // Order and payment successfully made - no downloadable items
		 $message['payment_nodownload'] 	= JText::_('COM_PHOCACART_ORDER_AND_PAYMENT_SUCCESSFULLY_PROCESSED')
		 .'</br>' . JText::_('COM_PHOCACART_ORDER_PAYMENT_PROCESSED_ADDITIONAL_INFO');
		 // Order and payment successfully made - downloadable items
		 $message['payment_download']	= JText::_('COM_PHOCACART_ORDER_AND_PAYMENT_SUCCESSFULLY_PROCESSED')
		 .'</br>' . JText::_('COM_PHOCACART_ORDER_PAYMENT_PROCESSED_DOWNLOADABLE_ITEMS_ADDITIONAL_INFO');
		 */
		
		return true;
	}

	/**
	 * Payment Canceled
	 *
	 * @param   integer	$mid  ID of message - can be set in PCPbeforeSetPaymentForm
	 * @param   string	$message  Custom message array set by plugin to override standard messages made by component
	 *
	 * @return  boolean  True
	 */
	
	function PCPafterCancelPayment($mid, &$message){
		
		$message = array();
		/*
		 switch($mid) {
		 case 1:
		 $message['payment_canceled']	= JText::_('COM_PHOCACART_PAYMENT_CANCELED')
		 .'</br>' . JText::_('COM_PHOCACART_ORDER_PAYMENT_CANCELED_ADDITIONAL_INFO');
		 break;
		 default:
		 $message['payment_canceled']	= JText::_('COM_PHOCACART_PAYMENT_CANCELED')
		 .'</br>' . JText::_('COM_PHOCACART_ORDER_PAYMENT_CANCELED_ADDITIONAL_INFO');
		 break;
		 }
		 */
		return true;
	}
	
	
	function PCPbeforeSetPaymentForm(&$form, $paramsC, $params, $order) {

		$client = new Client();
		$document			= JFactory::getDocument();
		$testmode			= $params->get('testmode', 1);
		$shopId				= $params->get('shopId', '');
		$secretKey			= $params->get('secretKey', '');
		$testshopId			= $params->get('testshopId', '');
		$testsecretKey		= $params->get('testsecretKey', '');
		$vat_code			= $params->get('vat_code', '');
		$tax_system_code	= $params->get('tax_system_code', '');
		$payment_method_type= $params->get('payment_method_type', '');
		$set_payment_method = $params->get('set_payment_method', '');
		$check_payment_status = $params->get('check_payment_status', '');
		// Два аргумента по ФФД 1.05
		$paymentMode		= $params->get('paymentMode', 1);
		$paymentSubject		= $params->get('paymentSubject', 1);
		
		
		$invoice_prefix		= $paramsC->get( 'invoice_prefix', '');
		$invoiceNr			= PhocaCartOrder::getInvoiceNumber($order['common']->id, $invoice_prefix);
		$orderNr			= PhocaCartOrder::getOrderNumber($order['common']->id);
		$itemName			= JText::_('COM_PHOCACART_ORDER') . ': ' . $orderNr;
		// Add discounts to order
		if(!isset($order['discounts'])){
			$oborder 			= new PhocacartOrderView();
			$order['discounts']	= $oborder->getItemProductDiscounts($order['common']->id, 0);
		}
		if (isset($order['common']->payment_id) && (int)$order['common']->payment_id > 0) {
			$paymentId = (int)$order['common']->payment_id;
		} else {
			$paymentId = 0;
		}
		$return 		= JURI::root(false). 'index.php?option=com_phocacart&view=response&task=response.paymentrecieve';
		$cancel_return 	= JURI::root(false). 'index.php?option=com_phocacart&view=response&task=response.paymentcancel';
		$notify_url 	= JURI::root(false). 'index.php?option=com_phocacart&view=response&task=response.paymentnotify&tmpl=component&type=spn_yandex_kassa';
		$return_url		= JURI::root(false). 'index.php?option=com_phocacart&view=response&task=response.paymentrecieve';
//		
		$b = $order['bas']['b'];
				 
		$netto=0; 	$tax=0;	$brutto=0;
		foreach ($order['total'] as $k => $v) {
			if($v->type=="netto"){
				$netto=$v->amount;
			}
			if($v->type=="tax"){
				$tax=$v->amount;
			}
			if($v->type=="brutto"){
				$brutto=$v->amount;
			}
		}

		$description="Оплата по счету ".$orderNr.", заказчик: ".$b['email']." / ".$b['phone_mobile'];

		$phone=$b['phone_mobile'];
		$email=$b['email'];

		try {
			$receipt = new Receipt();
			//$receipt->setPhone($phone);
			//$receipt->setTaxSystemCode($tax_system_code);
			$receipt->setEmail($email);
			//$instance->setReceipt($receipt);
			
			foreach ($order['products'] as $k => $v) {
				$attr="";
				$item = new ReceiptItem();
				if (isset($v->attributes)){
					foreach ($v->attributes as $k2 => $v2) {
						$attr.=$v2->attribute_title.' '.$v2->option_title;
					}
					$attr=" (".$attr.")";
				}
				$item->setDescription($v->title);
				$item->setVatCode($vat_code);
				$item->setQuantity((int)$v->quantity);
				$item->setIsShipping(false);
				$price_brutto=$v->brutto; // price brutto from product
				foreach($order['discounts'] as $kd => $vd){
					foreach($vd as $okd => $ovd){
						if ($ovd->product_id == $v->product_id){
							$price_brutto=$ovd->brutto;
						}
					}
				}
				$item->setPrice(new MonetaryAmount(sprintf("%.2f",$price_brutto)));
				// Аргументы ФФД 1.05
				$item->setPaymentMode($this->getPaymentMode($paymentMode));
				$item->setPaymentSubject($this->getPaymentSubject($paymentSubject));
				
				//
				$receipt->addItem($item);
			}
			// $withShipping = true;
			//$receipt->normalize(new MonetaryAmount(sprintf("%.2f",$brutto)), $withShipping);
		}
		catch (\Exception $e) {
			PhocacartLog::add(1, 'Error create Receipt object! '.$e->getMessage(), (int)$order['common']->id,'');
			return false;
		}

		try {
			$confirmation = array(
				'type' => ConfirmationType::REDIRECT,
				'returnUrl' => $return_url
			);
			if($set_payment_method == "1"){
				$Payment_methods=$this->getPaymentMethods();
				$pmt=$Payment_methods[$payment_method_type][0];
			}
			else {
				$pmt=null;
			}
			$payment = CreatePaymentRequest::builder()
				->setAmount(sprintf("%.2f",$brutto))
				->setCurrency('RUB')  // $order['common']->currency_code
				//->setCapture(true)
				//->setClientIp($_SERVER['REMOTE_ADDR'])
				->setDescription($description)
				->setReceipt($receipt)
				//->setPaymentToken(\YandexCheckout\Helpers\Random::str(36))
				//->setRecipient()
				//->setPaymentMethodData(new PaymentDataBankCard())
				//->setPaymentMethodData(PaymentMethodType::BANK_CARD)
				->setConfirmation($confirmation)
				->setPaymentMethodData($pmt)
				->build();
		} 
		catch (\Exception $e) {
			PhocacartLog::add(1,JText::_('PLG_PCP_YANDEX_KASSA_CREATE_PAYMENT_ERROR')." ".$e->getMessage(), (int)$order['common']->id,'');
			return false;
		}
error_log(print_r($payment,true));
		try{
			if($testmode){
				$client->setAuth($testshopId, $testsecretKey);
			}
			else {
				$client->setAuth($shopId, $secretKey);
			}
//error_log(print_r($client,true));
			$idempotenceKey = uniqid('', true);
error_log("... Создаем платеж..." );
			$response = $client->createPayment($payment,$idempotenceKey);
//error_log(print_r($response,true));
		}
		catch (\Exception $e) {
			PhocacartLog::add(1, JText::_('PLG_PCP_YANDEX_KASSA_CREATE_PAYMENT_RESPONSE_ERROR')." ".$e->getMessage(), (int)$order['common']->id,'');
			JFactory::getApplication()->enqueueMessage(JText::_('PLG_PCP_YANDEX_KASSA_CREATE_PAYMENT_RESPONSE_ERROR')." ".$e->getMessage(), 'message');
			return false;
		}
		if($response!=null){
			if($check_payment_status){
				// Save the needed code message & paymentid
				$session = JFactory::getSession();
				$session->set('infoaction', 6, 'phocaCart');
				$session->set('infomessage', array(), 'phocaCart');
				$session->set('ykpaymentid',$response->getId(), 'phocaCart');
			}
			$this->changeTokenInOrder((int)$order['common']->id,$response->getId());
			$app = JFactory::getApplication();
			$confirmation = $response->getConfirmation();
			if ($confirmation instanceof \YandexCheckout\Model\Confirmation\ConfirmationRedirect) {
				$payurl=$confirmation->getConfirmationUrl();
				PhocacartLog::add(1, JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_REDIRECT'),(int)$order['common']->id,$payurl);
				$app->redirect(JRoute::_($payurl, false));
			} else {
				PhocacartLog::add(1,JText::_('PLG_PCP_YANDEX_KASSA_REDIRECT_RETURN_URL'),(int)$order['common']->id,$return_url);
				$app->redirect(JRoute::_($return_url, false));
			}
			
		}
		return true;
	}
	
	function PCPbeforeCheckPayment($pid) {

	$context=file_get_contents("php://input");
	$not=json_decode($context);
	if(is_object($not) && isset($not->type) && $not->type == 'notification'){
		// Find PhOrder and get payment info
		$yid=$not->object->id;
		$order 			= new PhocacartOrderView();
		$payment		= new PhocacartPayment();
		$id=$this->getOrderByToken($yid);
		$o['common']	= $order->getItemCommon($id);
		if (isset($o['common']->payment_id) && (int)$o['common']->payment_id > 0) {
			$paymentO = $payment->getPaymentMethod((int)$o['common']->payment_id );
			$params=$paymentO->params;
		}
		$testmode			= $params->get('testmode', 1);
		$shopId				= $params->get('shopId', '');
		$secretKey			= $params->get('secretKey', '');
		$testshopId			= $params->get('testshopId', '');
		$testsecretKey		= $params->get('testsecretKey', '');
		try{
			$client = new Client();
			if($testmode){
				$client->setAuth($testshopId, $testsecretKey);
			}
			else {
				$client->setAuth($shopId, $secretKey);
			}
			$responsePI = $client->getPaymentInfo($yid);
		}
		catch (\Exception $e) {
			PhocacartLog::add(1,JText::_('PLG_PCP_YANDEX_KASSA_NOTIFICATION_PAYMENT_RESPONSE_ERROR')." ".$e->getMessage(), (int)$id,'');
			return false;
		}
		$cs=$responsePI->getStatus();
		// Payment amount
		$pa=$responsePI->getAmount()->getValue();
		// Order amount in DB
		$o['total']	= $order->getItemTotal($id);
		$oa=0; // Order amount
		foreach ($o['total'] as $k => $v) {
			if($v->type=="brutto"){
				$oa=$v->amount;
			}
		}
		$pa=sprintf("%.2f",$pa);
		$oa=sprintf("%.2f",$oa);
		// if found Order in db and got payment from yandex => check the payment status in yandex
		if($not->event=='payment.waiting_for_capture'){
			if($cs=='waiting_for_capture' && $pa==$oa){
				$response = null;
				try {
					$request = CreateCaptureRequest::builder()->setAmount($responsePI->getAmount())->build();
					$client = new Client();
					if($testmode){
						$client->setAuth($testshopId, $testsecretKey);
					}
					else {
						$client->setAuth($shopId, $secretKey);
					}
					$responsePI = $client->getPaymentInfo($yid);
					$key = uniqid('', true);

					$response = $client->capturePayment($request, $yid, $key);
					
					$tries = 0;
					while ($response === null){
						sleep(2);
						$response = $this->getApiClient()->capturePayment($request, $yid, $key);
						$tries++;
						if ($tries >= 3){
							break;
						}
					}
					if($response!=null && $response->getStatus()=='succeeded'){
						$this->changeStatusInOrder($id, 2, 0);
					}
				} catch (\Exception $e) {
					PhocacartLog::add(1,JText::_('PLG_PCP_YANDEX_KASSA_CAPTURE_PAYMENT_RESPONSE_ERROR')." ".$e->getMessage(), (int)$id,'');
				}
			}
			elseif($cs=='succeeded' && $pa==$oa){
				$this->changeStatusInOrder($id, 2, 0);
				PhocacartLog::add(1, JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_NOTIFICATION_YES'), (int)$id,JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_REQUEST_NOTIFICATION_ERROR_SUCCEEDED'));
			}
			elseif($cs=='pending'){
				// Client not paid!!!
				PhocacartLog::add(1,JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_NOTIFICATION_NO'), (int)$id,JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_REQUEST_NOTIFICATION_ERROR_PENDING'));
			}
		}
		elseif($not->event=='payment.succeeded'){
			if($cs=='succeeded' && $pa==$oa){
				$this->changeStatusInOrder($id, 2, 0);
			}
			else {
				PhocacartLog::add(1,JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_NOTIFICATION_NO'), (int)$id,JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_REQUEST_NOTIFICATION_ERROR_NOSUCCEEDED'.$cs));
			}
		}
		else {
			PhocacartLog::add(1,JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_NOTIFICATION_NO'), (int)$id,JText::_('PLG_PCP_YANDEX_KASSA_PAYMENT_REQUEST_NOTIFICATION_ERROR_STRANGE'.$not->event));
		}
	}
	exit(0);
	}

}
?>